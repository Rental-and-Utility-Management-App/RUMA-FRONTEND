import { Routes } from '@angular/router';

export const PROFILE_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () => import('./profile-detail/profile.page').then((m) => m.ProfilePage),
  },
];
